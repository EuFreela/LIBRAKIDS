package com.estudelibras.utils;

public class Host {
    //url padrão para acesso ao servidor local
    public static final String URL = "http://192.168.14.103/estudelibras/";

    //url padrão para acesso ao servidor local na pasta de imagens
    public static final String IMAGES = "http://192.168.14.103/estudelibras/images";

    //url padrão para acesso ao servidor local na pasta de videos
    public static final String VIDEOS = "http://192.168.14.103/estudelibras/videos";
}