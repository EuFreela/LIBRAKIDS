package com.estudelibras.controller;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.estudelibras.R;
import com.estudelibras.model.Card;
import com.estudelibras.utils.CardAdapter;
import com.estudelibras.utils.Host;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;
import java.util.List;

public class CardListaActivity extends AppCompatActivity {

    final List<Card> cards1 = new ArrayList<Card>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_card);

        Intent intent = getIntent();

        //recupera o idCategoria vindo do MenuCategoriaActivity
        final String idCategoria = intent.getStringExtra("idCategoria");

        Ion.with(CardListaActivity.this)
                .load(Host.URL + "cards.php")
                .setBodyParameter("categoria_id", idCategoria) //envia para o servidor o id da categoria
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        try{

                            JsonArray cardArray = result.getAsJsonArray("cards");
                            for(int i = 0; i< cardArray.size(); i++) {

                                JsonObject card = cardArray.get(i).getAsJsonObject();

                                //adiciona os cards/tutoriais do banco em uma lista
                                cards1.add(new Card(card.get("id").getAsString(),
                                        card.get("nome").getAsString(), card.get("imagem").getAsString(),
                                        card.get("categoria").getAsString(), card.get("video").getAsString()));

                            }

                            //monta a lista de cards que existem no banco
                            ListView listView = (ListView) findViewById(R.id.card_list_view);
                            CardAdapter cardAdapter = new CardAdapter(CardListaActivity.this, R.layout.card_lista, cards1);
                            listView.setAdapter(cardAdapter);

                            //ao clicar no item, o id do card é enviado para a tela de Tutorial/Aula
                            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                                    Intent intent = new Intent(CardListaActivity.this, TutorialActivity.class);
                                    intent.putExtra("idCard", cards1.get(i).getId());
                                    startActivity(intent);
                                }
                            });

                        } catch (Exception erro){

                            Toast.makeText(CardListaActivity.this, "Não há dados.", Toast.LENGTH_LONG).show();

                        }


                    }
                });
    }
}
