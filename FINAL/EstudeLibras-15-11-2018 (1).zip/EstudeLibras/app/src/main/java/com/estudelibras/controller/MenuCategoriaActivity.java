package com.estudelibras.controller;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.estudelibras.R;
import com.estudelibras.utils.Host;
import com.squareup.picasso.Picasso;

public class MenuCategoriaActivity extends AppCompatActivity {

    private ImageView aulasIcone;
    private ImageView quizIcone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_categoria);

        Intent intent = getIntent();
        final String idCategoria = intent.getStringExtra("idCategoria");

        aulasIcone = (ImageView) findViewById(R.id.menuAula);
        quizIcone = (ImageView) findViewById(R.id.menuQuiz);

        Picasso.get().load(Host.IMAGES + "/icons/aulas.png").into(aulasIcone);

        Picasso.get().load(Host.IMAGES + "/icons/quiz.png").into(quizIcone);

        aulasIcone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuCategoriaActivity.this, CardListaActivity.class);
                intent.putExtra("idCategoria", idCategoria);
                startActivity(intent);
            }
        });

        quizIcone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MenuCategoriaActivity.this, QuizActivity.class);
                intent.putExtra("idCategoria", idCategoria);
                startActivity(intent);
            }
        });
    }
}
