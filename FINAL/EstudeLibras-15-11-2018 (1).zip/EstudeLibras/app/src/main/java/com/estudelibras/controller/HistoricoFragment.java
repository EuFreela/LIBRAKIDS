package com.estudelibras.controller;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.estudelibras.R;
import com.estudelibras.model.Card;
import com.estudelibras.model.Historico;
import com.estudelibras.utils.CardAdapter;
import com.estudelibras.utils.HistoricoAdapter;
import com.estudelibras.utils.Host;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;
import java.util.List;

public class HistoricoFragment extends Fragment {

    @Nullable
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view =inflater.inflate(
                R.layout.historico_fragment_layout,
                container,
                false);

        final SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("preferencias", Context.MODE_PRIVATE);

        Ion.with(HistoricoFragment.this)
                .load(Host.URL + "historico.php")
                .setBodyParameter("usuario_id", sharedPreferences.getString("idUsuario", "0"))
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        try{
                            JsonArray historicoArray = result.getAsJsonArray("history");
                            List<Historico> historicos = new ArrayList<Historico>();

                            float acerto = 0;
                            float erro = 0;
                            float total = historicoArray.size();

                            for(int i = 0; i< historicoArray.size(); i++) {

                                JsonObject historico = historicoArray.get(i).getAsJsonObject();
                                //texto.setText(card.get("nome").getAsString());
                                historicos.add(new Historico(historico.get("id").getAsString(),
                                        historico.get("escolha").getAsString(),
                                        historico.get("status_choice").getAsString(),
                                        historico.get("user_id").getAsString(),
                                        historico.get("quiz_id").getAsString()));

                                if(historico.get("status_choice").getAsString().equalsIgnoreCase("acertou")){
                                    acerto++;
                                }else {
                                    erro++;
                                }

                            }

                            ListView listView = (ListView) view.findViewById(R.id.historico_list_view);
                            HistoricoAdapter cardAdapter = new HistoricoAdapter(getActivity(), R.layout.card_lista, historicos);
                            listView.setAdapter(cardAdapter);


//                            PieChart pieChart = (PieChart) view.findViewById(R.id.piechart);
//
//                            pieChart.setUsePercentValues(true);
//                            pieChart.getDescription().setEnabled(true);
//                            pieChart.setExtraOffsets(5,10,5,5);
//                            pieChart.setDragDecelerationFrictionCoef(0.9f);
//                            pieChart.setTransparentCircleRadius(61f);
//                            pieChart.setDrawHoleEnabled(false);
//                            pieChart.animateY(1000, Easing.EasingOption.EaseInOutCubic);
//
//
//                            List<PieEntry> entries = new ArrayList<>();
//
//                            entries.add(new PieEntry(acerto, "Acertou"));
//                            entries.add(new PieEntry(erro, "Errou"));
//
//                            PieDataSet set = new PieDataSet(entries, "Quiz");
//                            set.setColors(new int[]{Color.parseColor("#3366CC"),
//                                    Color.parseColor("#DC3912")});
//                            PieData data = new PieData(set);
//                            pieChart.setData(data);
//                            pieChart.invalidate(); // refresh

                        } catch (Exception erro){

                        }


                    }
                });
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("aqui","chegou");
//        getActivity().recreate();
    }
}

