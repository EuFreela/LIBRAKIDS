package com.estudelibras.model;

public class Card {

    private String id;
    private String nome;
    private String imagem;
    private String categoria;
    private String video;

    public Card(String id, String nome, String imagem, String categoria, String video){
        this.id = id;
        this.nome = nome;
        this.imagem = imagem;
        this.categoria = categoria;
        this.video = video;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getImagem() {
        return imagem;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getVideo() {
        return video;
    }

    public void setVideo(String video) {
        this.video = video;
    }

    @Override
    public String toString() {
        return "Card{" +
                "id='" + id + '\'' +
                ", nome='" + nome + '\'' +
                ", imagem='" + imagem + '\'' +
                ", categoria='" + categoria + '\'' +
                ", video='" + video + '\'' +
                '}';
    }
}
