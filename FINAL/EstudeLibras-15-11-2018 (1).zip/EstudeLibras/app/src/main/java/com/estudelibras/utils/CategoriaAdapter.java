package com.estudelibras.utils;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.estudelibras.R;
import com.estudelibras.model.Categoria;
import com.estudelibras.model.Historico;
import com.squareup.picasso.Picasso;

import java.util.List;

public class CategoriaAdapter extends ArrayAdapter<Categoria> {

    private List<Categoria> categorias;

    public CategoriaAdapter(@NonNull Context context, int resource, @NonNull List<Categoria> categorias) {
        super(context, resource, categorias);
        this.categorias = categorias;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View view, @NonNull ViewGroup parent) {
        View listItem = null;
        CategoriaAdapter.ViewHolder holder = null;

        if(view == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            listItem = inflater.inflate(R.layout.card_lista, null, true);

            holder = new CategoriaAdapter.ViewHolder();
            holder.categoriaImagem = (ImageView) listItem.findViewById(R.id.card_image);
            holder.categoriaNome = (TextView) listItem.findViewById(R.id.card_titulo);

            listItem.setTag(holder);
        } else{
            listItem = view;
            holder = (CategoriaAdapter.ViewHolder) view.getTag();
        }

        //exibem imagem e titulo
        holder.categoriaNome.setText(categorias.get(position).getNome());
        Picasso.get().load(Host.IMAGES+categorias.get(position).getImagem()).into(holder.categoriaImagem);

        return listItem;
    }

    static class ViewHolder {
        ImageView categoriaImagem;
        TextView categoriaNome;

    }
}
