package com.estudelibras.controller;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.annotation.DrawableRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.estudelibras.R;
import com.estudelibras.model.Card;
import com.estudelibras.model.Quiz;
import com.estudelibras.utils.Host;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class QuizActivity extends AppCompatActivity {

    private WebView videoQuiz;
    private ImageView resposta;
    private ImageView imagem1;
    private ImageView imagem2;
    private ImageView imagem3;

    String idCategoria;

    //pega dados que virão do banco
    private List<Quiz> quizList = new ArrayList<Quiz>();

    //representa a posicao de quiz na lista quizLista
    private int quizPosicao = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        Intent intent = getIntent();
        idCategoria = intent.getStringExtra("idCategoria");

        videoQuiz = (WebView) findViewById(R.id.quizVideo);
        imagem1 = (ImageView) findViewById(R.id.image1);
        imagem2 = (ImageView) findViewById(R.id.image2);
        imagem3 = (ImageView) findViewById(R.id.image3);

        //Inicializa o quiz pegando dados do servidor
        chamaDadosQuiz(idCategoria);

    }

    public void chamaDadosQuiz(String idCategoria){
        Ion.with(QuizActivity.this)
                .load(Host.URL + "categoria_quiz.php")
                .setBodyParameter("id_categoria", idCategoria)
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        try{

                            JsonArray quizArray = result.getAsJsonArray("quiz");
                            List<Quiz> quizList2 = new ArrayList<Quiz>();

                           for(int i = 0; i < quizArray.size(); i++) {
                                JsonObject quizJson = quizArray.get(i).getAsJsonObject();

                                //salva dados vindo do banco numa lista
                               quizList.add(new Quiz(quizJson.get("id").getAsString(),
                                        quizJson.get("pergunta").getAsString(), quizJson.get("resposta1").getAsString(),
                                        quizJson.get("resposta2").getAsString(), quizJson.get("resposta3").getAsString(),
                                        quizJson.get("respostaCorreta").getAsString()));

                           }

                            atualizaQuiz();


                        } catch (Exception erro){
                            Toast.makeText(QuizActivity.this, "Ops, ocorreu um erro.", Toast.LENGTH_LONG).show();

                        }

                    }
                });
    }

    public void atualizaQuiz(){
        //caso exista quiz no banco e ainda tenha quiz que não foi exibido, carrega o próximo quiz
        if((quizList.size() > 0) && (quizPosicao < quizList.size())){
            final Quiz quiz = quizList.get(quizPosicao);

            videoQuiz = (WebView) findViewById(R.id.quizVideo);
            videoQuiz.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    return false;
                }
            });

            WebSettings webSettings = videoQuiz.getSettings();
            webSettings.setJavaScriptEnabled(true);
            videoQuiz.loadUrl(Host.VIDEOS + quiz.getPergunta());

            //IMAGEM 1
            final ImageView imagem1 = (ImageView) findViewById(R.id.image1);
            Picasso.get().load(Host.IMAGES + quiz.getResposta1()).into(imagem1);

            //IMAGEM 2
            final ImageView imagem2 = (ImageView) findViewById(R.id.image2);
            Picasso.get().load(Host.IMAGES + quiz.getResposta2()).into(imagem2);

            //IMAGEM 3
            final ImageView imagem3 = (ImageView) findViewById(R.id.image3);
            Picasso.get().load(Host.IMAGES + quiz.getResposta3()).into(imagem3);

            imagem1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    clearBackground();

                    if(quiz != null) {
                        respostaCorreta(quiz.getId(), quiz.getResposta1(),
                                quiz.getRespostaCorreta(),imagem1);
                    }

                }
            });

            imagem2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    clearBackground();

                    if(quiz != null) {
                        respostaCorreta(quiz.getId(), quiz.getResposta2(),
                                quiz.getRespostaCorreta(),imagem2);
                    }

                }
            });

            imagem3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    clearBackground();

                    if(quiz != null) {
                        respostaCorreta(quiz.getId(), quiz.getResposta3(),
                                quiz.getRespostaCorreta(),imagem3);
                    }

                }
            });

            quizPosicao++; //incrementa a posição para o próximo quiz

        } else{


            Intent intent = new Intent(QuizActivity.this, MenuCategoriaActivity.class);
            intent.putExtra("idCategoria", idCategoria);
            startActivity(intent);
            finish();

        }

    }

    public void clearBackground(){
        imagem1.setBackgroundColor(Color.TRANSPARENT);
        imagem2.setBackgroundColor(Color.TRANSPARENT);
        imagem3.setBackgroundColor(Color.TRANSPARENT);
    }

    public void respostaCorreta(String quizId, String escolhaUsuario, String respostaCerta, ImageView imgView){

        final SharedPreferences sharedPreferences = getSharedPreferences("preferencias", Context.MODE_PRIVATE);

        //caso a escolha do usuario for a correta adiciona ponto e salva histórico
        //caso não, apenas salva histórico
        if(escolhaUsuario.equals(respostaCerta)){

            Ion.with(QuizActivity.this)
                    .load(Host.URL + "addHistorico.php")
                    .setBodyParameter("id_usuario", sharedPreferences.getString("idUsuario", "0"))
                    .setBodyParameter("status", "acertou")
                    .setBodyParameter("id_quiz", quizId)
                    .setBodyParameter("escolha", escolhaUsuario)
                    .asJsonObject()
                    .setCallback(new FutureCallback<JsonObject>() {
                        @Override
                        public void onCompleted(Exception e, JsonObject result) {
                            try{

                            } catch (Exception erro){
                                Toast.makeText(QuizActivity.this, "Não há dados.", Toast.LENGTH_LONG).show();

                            }

                        }
                    });

            Toast.makeText(QuizActivity.this, "Acertou", Toast.LENGTH_LONG).show();
            atualizaQuiz();

        } else{
            Ion.with(QuizActivity.this)
                    .load(Host.URL + "addHistorico.php")
                    .setBodyParameter("id_usuario", sharedPreferences.getString("idUsuario", "0"))
                    .setBodyParameter("status", "errou")
                    .setBodyParameter("id_quiz", quizId)
                    .setBodyParameter("escolha", escolhaUsuario)
                    .asJsonObject()
                    .setCallback(new FutureCallback<JsonObject>() {
                        @Override
                        public void onCompleted(Exception e, JsonObject result) {
                            try{

                            } catch (Exception erro){
                                Toast.makeText(QuizActivity.this, "Não há dados.", Toast.LENGTH_LONG).show();

                            }

                        }
                    });

            Toast.makeText(QuizActivity.this, "Errou", Toast.LENGTH_LONG).show();
            imgView.setBackground(getDrawable(R.drawable.border_image));
//            atualizaQuiz();

        }
    }
}
