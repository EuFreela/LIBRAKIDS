package com.estudelibras.utils;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.estudelibras.R;
import com.estudelibras.model.Card;
import com.squareup.picasso.Picasso;

import java.util.List;

public class CardAdapter extends ArrayAdapter<Card> {

    private List<Card> cards;

    public CardAdapter(@NonNull Context context, int resource, @NonNull List<Card> cards) {
        super(context, resource, cards);
        this.cards = cards;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View view, @NonNull ViewGroup parent) {
        View listItem = null;
        ViewHolder holder = null;

        if(view == null) {
            LayoutInflater inflater = LayoutInflater.from(getContext());
            listItem = inflater.inflate(R.layout.card_lista, null, true);

            holder = new ViewHolder();
            holder.cardImagem = (ImageView) listItem.findViewById(R.id.card_image);
            holder.cardTitulo = (TextView) listItem.findViewById(R.id.card_titulo);

            listItem.setTag(holder);
        } else{
            listItem = view;
            holder = (ViewHolder) view.getTag();
        }

        //exibem imagem e titulo
        Picasso.get().load(Host.IMAGES+cards.get(position).getImagem()).into(holder.cardImagem);
        holder.cardTitulo.setText(cards.get(position).getNome());

        return listItem;
    }

    static class ViewHolder {
        ImageView cardImagem; //imagem
        TextView cardTitulo; //titulo
    }
}
