package com.estudelibras.controller;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.estudelibras.R;
import com.estudelibras.model.Categoria;
import com.estudelibras.utils.CategoriaAdapter;
import com.estudelibras.utils.Host;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;
import java.util.List;

public class CategoriasFragment extends Fragment {
    final List<Categoria> categorias = new ArrayList<Categoria>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view =  inflater.inflate(R.layout.categoria_fragment_layout, container, false);

        Ion.with(CategoriasFragment.this)
                .load(Host.URL + "categoria.php")
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        try{

                            JsonArray categoriaArray = result.getAsJsonArray("categorias");
                            Log.e("cat","retorno"+categoriaArray.size());
                            categorias.clear();
                            for(int i = 0; i< categoriaArray.size(); i++) {

                                JsonObject categoria = categoriaArray.get(i).getAsJsonObject();

                                categorias.add(new Categoria(categoria.get("id").getAsString(),
                                        categoria.get("nome").getAsString(), categoria.get("imagem").getAsString()));

                            }

                            Log.e("cat", "qyd"+categorias.size());

                            ListView listView = (ListView) view.findViewById(R.id.categoria_list_view);
                            CategoriaAdapter cardAdapter = new CategoriaAdapter(getActivity(), R.layout.card_lista, categorias);
                            listView.setAdapter(cardAdapter);

                            //ao clicar no item, o id da categoria é enviado para a tela de MenuCategoria
                            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                                    Intent intent = new Intent(getActivity(), MenuCategoriaActivity.class);
                                    intent.putExtra("idCategoria", categorias.get(i).getId());
                                    startActivity(intent);
                                }
                            });

                        } catch (Exception erro){

                            Toast.makeText(getActivity(), "Não há dado.", Toast.LENGTH_LONG).show();

                        }

                    }
                });

        return view;
    }

}
