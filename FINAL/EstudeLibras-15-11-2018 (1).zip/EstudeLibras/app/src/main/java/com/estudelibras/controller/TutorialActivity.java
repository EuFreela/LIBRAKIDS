package com.estudelibras.controller;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.estudelibras.R;
import com.estudelibras.utils.Host;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.squareup.picasso.Picasso;

public class TutorialActivity extends AppCompatActivity {

    private WebView videoTurotial;
    private String idCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial);

        Intent intent = getIntent();
        idCard = intent.getStringExtra("idCard");

        carregarTutorial(idCard);

    }

    public void carregarTutorial(String tutorialId){

        Ion.with(TutorialActivity.this)
                .load(Host.URL + "tutorial.php")
                .setBodyParameter("id_tutorial", tutorialId)
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        try{
                            //TextView titulo = (TextView) findViewById(R.id.tutorialTitulo);
                            //titulo.setText(result.get("nome").getAsString());

                            videoTurotial = (WebView) findViewById(R.id.tutorialVideo);
                            videoTurotial.setWebViewClient(new WebViewClient() {
                                @Override
                                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                                    return false;
                                }
                            });

                            //pega o link do video do youtube e insere na webview
                            WebSettings webSettings = videoTurotial.getSettings();
                            webSettings.setJavaScriptEnabled(true);
                            videoTurotial.loadUrl(Host.VIDEOS + result.get("video").getAsString());

                            Button lento = (Button) findViewById(R.id.lento);

                            lento.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent(TutorialActivity.this, TutorialLentoActivity.class);
                                    intent.putExtra("idCard", idCard);
                                    startActivity(intent);
                                }
                            });

                            ImageView imagem = (ImageView) findViewById(R.id.tutorialImagem);
                            Picasso.get().load(Host.IMAGES+result.get("imagem").getAsString()).into(imagem);

                            final String idCategoria = result.get("categoria").getAsString();

                            ImageView irParaQuiz = (ImageView) findViewById(R.id.irParaQuiz);
                            Picasso.get().load(Host.IMAGES+"/icons/quiz.png").into(irParaQuiz);
                            irParaQuiz.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View view) {
                                    Intent intent = new Intent(TutorialActivity.this, QuizActivity.class);
                                    intent.putExtra("idCategoria", idCategoria);
                                    startActivity(intent);
                                }
                            });

                        } catch (Exception erro){
                            Toast.makeText(TutorialActivity.this, "Não há dados.", Toast.LENGTH_LONG).show();

                        }


                    }
                });
    }
}
