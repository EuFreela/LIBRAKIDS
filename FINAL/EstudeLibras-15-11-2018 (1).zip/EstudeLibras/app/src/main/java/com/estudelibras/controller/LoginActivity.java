package com.estudelibras.controller;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.estudelibras.R;
import com.estudelibras.utils.Host;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

public class LoginActivity extends AppCompatActivity {

    private EditText edEmail, edSenha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        autoLogin();
        //setContentView(R.layout.activity_login);

        edEmail = (EditText) findViewById(R.id.editEmailLogin);
        edSenha = (EditText) findViewById(R.id.editSenhaLogin);
    }

    public void autoLogin(){
        String emailLogin = "libras@libras.com";
        String senhaLogin = "1234";

        Ion.with(LoginActivity.this)
                .load(Host.URL + "login.php")
                .setBodyParameter("email_login", emailLogin)
                .setBodyParameter("senha_login", senhaLogin)
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>(){
                    @Override
                    public void onCompleted(Exception e, JsonObject result) {
                        try{

                            String status = result.get("status").getAsString();

                            if(status.equals("sucesso")){

                                SharedPreferences sharedPreferences = getSharedPreferences("preferencias", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferences.edit();

                                editor.putString("idUsuario", result.get("id").getAsString());
                                editor.putString("nomeUsuario", result.get("nome").getAsString());
                                editor.putString("emailUsuario", result.get("email").getAsString());
                                editor.apply();

                                Intent intent = new Intent(LoginActivity.this,
                                        MainActivity.class);
                                intent.putExtra("emailUsuario", result.get("email").getAsString());

                                startActivity(intent);

                            }else if (status.equals("falha")){
                                Log.e("login", "erro");
                            }

                        } catch (Exception erro){
                            Log.e("login", "erro: " + erro);

                        }
                    }
                });
    }

    public void fazerLogin(View view){

        String emailLogin = edEmail.getText().toString();
        String senhaLogin = edSenha.getText().toString();

        if(!emailLogin.isEmpty() || !senhaLogin.isEmpty()){
            Ion.with(LoginActivity.this)
                    .load(Host.URL + "login.php")
                    .setBodyParameter("email_login", emailLogin)
                    .setBodyParameter("senha_login", senhaLogin)
                    .asJsonObject()
                    .setCallback(new FutureCallback<JsonObject>(){
                        @Override
                        public void onCompleted(Exception e, JsonObject result) {
                            try{

                                String status = result.get("status").getAsString();

                                if(status.equals("sucesso")){
                                    Toast.makeText(LoginActivity.this, "Login com sucesso!"
                                            , Toast.LENGTH_LONG).show();

                                    //pega os dados do login do usuário para persistir os dados em uma lista de preferencia
                                    //como uma sessão de usuário
                                    SharedPreferences sharedPreferences = getSharedPreferences("preferencias",
                                            Context.MODE_PRIVATE);
                                    SharedPreferences.Editor editor = sharedPreferences.edit();

                                    editor.putString("idUsuario", result.get("id").getAsString());
                                    editor.putString("nomeUsuario", result.get("nome").getAsString());
                                    editor.putString("emailUsuario", result.get("email").getAsString());
                                    editor.apply();

                                    Intent intent = new Intent(LoginActivity.this,
                                            MainActivity.class);
                                    intent.putExtra("emailUsuario", result.get("email").getAsString());
                                    
                                    startActivity(intent);

                                } else if(status.equals("falha")){
                                    Toast.makeText(LoginActivity.this, "Email ou senha "
                                            + "incorretos!", Toast.LENGTH_LONG).show();
                                } else{
                                    Toast.makeText(LoginActivity.this, "Ops, ocorreu algum "
                                            + "erro", Toast.LENGTH_LONG).show();
                                }

                            } catch (Exception erro){
                                Toast.makeText(LoginActivity.this, "Ops, ocorreu algum erro.",
                                        Toast.LENGTH_LONG).show();

                            }
                        }
                    });

        } else{
            Toast.makeText(LoginActivity.this, "Todos os campos precisam ser "
                    + "preenchidos", Toast.LENGTH_LONG).show();
        }

    }

    @Override
    protected void onPause() {
        super.onPause();

        finish();
    }
}
