package com.estudelibras.model;

public class Historico {

    private String id;
    private String escolha;
    private String status;
    private String usuarioId;
    private String quizId;

    public Historico(String id, String escolha, String status, String usuarioId, String quizId) {
        this.id = id;
        this.escolha = escolha;
        this.status = status;
        this.usuarioId = usuarioId;
        this.quizId = quizId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEscolha() {
        return escolha;
    }

    public void setEscolha(String escolha) {
        this.escolha = escolha;
    }

    public String getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(String usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getQuizId() {
        return quizId;
    }

    public void setQuizId(String quizId) {
        this.quizId = quizId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
