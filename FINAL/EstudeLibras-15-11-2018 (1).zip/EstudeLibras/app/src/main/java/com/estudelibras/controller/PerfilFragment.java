package com.estudelibras.controller;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.estudelibras.R;
import com.estudelibras.model.Historico;
import com.estudelibras.utils.Host;
import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

import java.util.ArrayList;
import java.util.List;

public class PerfilFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.perfil_fragment_layout, container, false);

        final SharedPreferences sharedPreferences = this.getActivity().getSharedPreferences("preferencias", Context.MODE_PRIVATE);

        if(getArguments() != null){
            String emailUsuario = getArguments().getString("emailUsuario");

            //envia par ao servidor o email do usuario e verifica se existe para mostrar os dados
            Ion.with(getActivity())
                    .load(Host.URL + "perfil.php")
                    .setBodyParameter("email_usuario", emailUsuario)
                    .asJsonObject()
                    .setCallback(new FutureCallback<JsonObject>() {
                        @Override
                        public void onCompleted(Exception e, JsonObject result) {

                            try{
                                //TextView nome = (TextView) view.findViewById(R.id.nomePerfil);
                                //nome.setText(result.get("nome").getAsString());


                                //TextView email = (TextView) view.findViewById(R.id.emailPerfil);
                                //email.setText(result.get("email").getAsString());

                                TextView pontos = (TextView) view.findViewById(R.id.pontosPerfil);
                                pontos.setText("PONTOS: " + result.get("pontos").getAsString());


                                Button apagar = (Button) view.findViewById(R.id.delete);
                                PieChart pieChart = (PieChart) view.findViewById(R.id.piechart);
                                if(pontos.getText().equals("Sem pontos.")||pontos.getText().equals("PONTOS: 0"))
                                {
                                    apagar.setEnabled(false);
                                    pieChart.setVisibility(View.INVISIBLE);

                                }else {
                                    apagar.setEnabled(true);
                                    apagar.setOnClickListener(new View.OnClickListener() {
                                        public void onClick(View v) {
                                            Log.d("click","clicou");
                                                Ion.with(PerfilFragment.this)
                                                        .load(Host.URL + "delHistorico.php")
                                                        .setBodyParameter("id_usuario", sharedPreferences.getString("idUsuario", "0"))
                                                        .asJsonObject()
                                                        .setCallback(new FutureCallback<JsonObject>() {
                                                            @Override
                                                            public void onCompleted(Exception e, JsonObject result) {
                                                                try{

                                                                } catch (Exception erro){
//                                                                    Toast.makeText(PerfilFragment.this, "Não há dados.", Toast.LENGTH_LONG).show();
                                                                    Log.e("delete-ponto","erro: " + erro);

                                                                }
                                                            }
                                                        });
                                            getActivity().recreate();
//                                                Toast.makeText(PerfilFragment.this, "Acertou", Toast.LENGTH_LONG).show();
                                        }
                                    });
                                }


                                Ion.with(PerfilFragment.this)
                                        .load(Host.URL + "historico.php")
                                        .setBodyParameter("usuario_id", sharedPreferences.getString("idUsuario", "0"))
                                        .asJsonObject()
                                        .setCallback(new FutureCallback<JsonObject>() {
                                            @Override
                                            public void onCompleted(Exception e, JsonObject result) {
                                                try{
                                                    JsonArray historicoArray = result.getAsJsonArray("history");
                                                    List<Historico> historicos = new ArrayList<Historico>();

                                                    float acerto = 0;
                                                    float erro = 0;
                                                    float total = historicoArray.size();

                                                    for(int i = 0; i< historicoArray.size(); i++) {

                                                        JsonObject historico = historicoArray.get(i).getAsJsonObject();
                                                        //texto.setText(card.get("nome").getAsString());
                                                        historicos.add(new Historico(historico.get("id").getAsString(),
                                                                historico.get("escolha").getAsString(),
                                                                historico.get("status_choice").getAsString(),
                                                                historico.get("user_id").getAsString(),
                                                                historico.get("quiz_id").getAsString()));

                                                        if(historico.get("status_choice").getAsString().equalsIgnoreCase("acertou")){
                                                            acerto++;
                                                        }else {
                                                            erro++;
                                                        }

                                                    }

                                                    PieChart pieChart = (PieChart) view.findViewById(R.id.piechart);
                                                    pieChart.setUsePercentValues(true);
                                                    pieChart.getDescription().setEnabled(true);
                                                    pieChart.setExtraOffsets(5,10,5,5);
                                                    pieChart.setDragDecelerationFrictionCoef(0.9f);
                                                    pieChart.setTransparentCircleRadius(61f);
                                                    pieChart.setDrawHoleEnabled(false);
                                                    pieChart.animateY(1000, Easing.EasingOption.EaseInOutCubic);


                                                    List<PieEntry> entries = new ArrayList<>();

                                                    entries.add(new PieEntry(acerto, "Acertou"));
                                                    entries.add(new PieEntry(erro, "Errou"));

                                                    PieDataSet set = new PieDataSet(entries, "Quiz");
                                                    set.setColors(new int[]{Color.parseColor("#3366CC"),
                                                            Color.parseColor("#DC3912")});
                                                    PieData data = new PieData(set);
                                                    pieChart.setData(data);
                                                    pieChart.invalidate(); // refresh

                                                } catch (Exception erro){

                                                }

                                            }
                                        });


                            } catch (Exception erro){
                                Toast.makeText(getActivity(), "Não há dados.", Toast.LENGTH_LONG).show();

                            }


                        }
                    });


        }

        return view;

    }

}
